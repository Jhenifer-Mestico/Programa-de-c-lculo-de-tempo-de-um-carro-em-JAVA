/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tempocarro;

/**
 *
 * @author Jhenifer
 */
import javax.swing.*;
public class TempoCarro {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double km, tempo, velocidade;
        
        km = Double.parseDouble(
                 JOptionPane.showInputDialog (null, 
                 "Digite o espaço em km percorridos: ", 
                 "Dado", JOptionPane.INFORMATION_MESSAGE) );
        
        tempo = Double.parseDouble(
                 JOptionPane.showInputDialog (null, 
                 "Digite o tempo em horas percorridos: ", 
                 "Dado", JOptionPane.INFORMATION_MESSAGE) );
        
        velocidade = tempo/km;
        
        if (km<0){
                 JOptionPane.showInputDialog (null, 
                 "O valor deve ser positivo" + km, 
                 "Resultado", JOptionPane.INFORMATION_MESSAGE);
        }
        
         else {
      JOptionPane.showMessageDialog (null, 
                 "O resultado será em Km/h" + velocidade,
                 "Resultado", JOptionPane.INFORMATION_MESSAGE);   
    }
    
}
}
